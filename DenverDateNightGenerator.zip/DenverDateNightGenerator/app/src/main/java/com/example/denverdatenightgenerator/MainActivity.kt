package com.example.denverdatenightgenerator

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    @SuppressLint("Range")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Button to generate new date idea on click
        val dateButton: Button = findViewById(R.id.button)
        dateButton.setOnClickListener {
                val generator = Generator()
                val date = generator.getDate()
                val resultTextView: TextView = findViewById(R.id.textView)
                resultTextView.text = date
        }
    }
}

class Generator {
    // List of potential date ideas
    private val dateList = listOf("Watch the sunset from the summit of Mt. Evans",
        "Grab Arepas from Avanti", "Watch a movie at the Alamo theater",
        "Watch a comedy show at Comedy Works", "Go go-karting at Unser Karting & Events",
        "Make candles at Candelaria", "Visit the Denver Botanic Gardens",
        "Visit the Denver Museum of Nature & Science", "Visit the Denver Zoo",
        "Play arcade games at 1Up", "Go rock climbing at Earth Treks",
        "Check out the Denver Escape Room", "Enjoy drinks at Williams & Graham, a speakeasy",
        "Go bowling at Lucky Strike", "Show off your swing at Topgolf",
        "Go mini golfing at Monster Mini Golf", "Go to a concert at Red Rocks Amphitheater",
        "Go salsa dancing at La Rumba", "Go axe throwing at Bad Axe Throwing",
        "Watch the sunset from the summit of Loveland Pass", "Go tubing on the Platte River",
        "Take a free candy factory tour at Hammond’s Candies", "Try goat yoga at Rocky Mountain Goat Yoga",
        "Look for wildlife at Rocky Mountain National Park", "Pick berries at Berry Patch Farm",
        "Go stand up paddle boarding on Evergreen Lake", "Drive Trail Ridge Road in Rocky Mountain National Park",
        "Try archery at No Limits", "Ride the Georgetown Loop Railroad", "Visit the Denver Aquarium",
        "Have a picnic at City Park", "Enjoy the murals in the RiNo arts district", "Go to a drive-in movie",
        "Take a cooking class at Uncorked Kitchen & Wine Bar", "Take a succulent workshop at Wild Flowers",
        "Make soap at I Made It! Workshop", "Have a wine and painting night at Painting With a Twist",
        "Drive out to Mount Princeton Hot Springs and enjoy the warm water", "Get ice cream from Little Man",
        "Attend an event at the Denver Performing Arts Complex", "Go to a Rockies game", "Go for a hike in Morrison")


    // Return a random date from the date list
    fun getDate(): String {
        return dateList.random()
    }
}
